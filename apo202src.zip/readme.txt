
Apophysis was written with Delphi 5.0

The rendering engine (with some modifications) comes
from a screensaver by Ronald Hordijk.
http://home.kabelfoon.nl/~rhordijk/progs.html#flame

The original flame code was written by Scott Draves.
http://flam3.com/index.cgi?&menu=code

To compile you'll need a few third-party controls and
libraries:

Scripter Studio
http://www.tmssoftware.com/scriptstudio.htm

ImageFileLib
http://www.logicnet.dk/lib/

XML Parser
http://www.destructor.de/

Indy Internet Components
http://www.indyproject.org/


